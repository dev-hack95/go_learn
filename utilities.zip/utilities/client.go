package utilities

import (
	b64 "encoding/base64"
	"net/http"

	"com.awesomesuite.project/utilities/config"
	"com.awesomesuite.project/utilities/logs"
	"github.com/spf13/cast"
)

func IsClientAuthentication(r *http.Request) bool {
	clientId := r.URL.Query().Get("client_id")
	clientKey := r.URL.Query().Get("client_key")

	if IsEmpty(clientId) && IsEmpty(clientKey) {
		clientId = r.Header.Get("client_id")
		clientKey = r.Header.Get("client_key")
	}

	return clientAuthentication(clientId, clientKey)
}

func clientAuthentication(clientId string, clientKey string) bool {
	if isProdEnv() {
		return prodClientAuthentication(clientId, clientKey)
	}

	if clientId == "" || clientKey == "" {
		return false
	}

	sDec, _ := b64.StdEncoding.DecodeString(clientKey)
	if clientId == cast.ToString(sDec) {
		logs.Info("clientId:", clientId, "clientKey:", clientKey)
		return true
	}
	return false
}

func isProdEnv() bool {
	return config.ENV == "prod"
}

func prodClientAuthentication(clientId string, clientKey string) bool {
	if clientId == "" || clientKey == "" {
		return false
	}

	sDec, _ := b64.StdEncoding.DecodeString(clientKey)
	sKey := clientId + "." + reverse(clientId)
	if sKey == cast.ToString(sDec) {
		logs.Info("clientId:", clientId, "clientKey:", clientKey)
		return true
	}

	return false
}

func reverse(s string) string {
	runes := []rune(s)
	for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
		runes[i], runes[j] = runes[j], runes[i]
	}
	return string(runes)
}
