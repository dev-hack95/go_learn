package utilities

import (
	"fmt"
	"net/http"

	"com.awesomesuite.project/utilities/config"
	"com.awesomesuite.project/utilities/config/errorMessage"
	"com.awesomesuite.project/utilities/config/persistent"
	"com.awesomesuite.project/utilities/config/swagger"
	"com.awesomesuite.project/utilities/logs"
	"github.com/akrylysov/algnhsa"
	"github.com/rs/cors"
)

const SHA_HASH_KEY = "f2a12dfcf910a464d48ca317797634d2e29d82ed75d2cba1b9f907d5ede0842e"

func EnableAutoConfiguration() {
	config.SetConfigurationProperties()
	config.SetServiceContextPath()
	persistent.RegisterDatabase(config.ENV, "")
	errorMessage.SetErrorMessageProperties()
	swagger.SetupSwagger(config.ENV)
}

func StartApplication(mux *http.ServeMux, port string, isCorsEnable bool) {
	//append swagger handle
	if swagger.IS_ENABLE_SWAGGER {
		HandleFunc(mux, "/swagger", swagger.SwaggerHandler)
	}

	//port on running
	if config.ENV == "local" {
		fmt.Println("port: ", port)
		if err := http.ListenAndServe(":"+port, mux); err != nil {
			logs.Error("error : ", err.Error())
		}
	} else {
		//is cors required
		if isCorsEnable {
			handler := cors.AllowAll().Handler(mux)
			algnhsa.ListenAndServe(handler, nil)
		} else {
			algnhsa.ListenAndServe(mux, nil)
		}
	}
	fmt.Println("Start ...")
}
