package utilities

func ProductNameByID(productId int) string {
	if productId == 1 {
		return "AwesomeSocial"
	} else if productId == 2 {
		return "AwesomeSign"
	} else if productId == 3 {
		return "AwesomeDial"
	}
	return "AwesomeSuite"
}
