package utilities

import (
	b64 "encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"
    "com.awesomesuite.project/utilities/config"
	"com.awesomesuite.project/utilities/logs"
	"github.com/astaxie/beego/orm"
	"github.com/spf13/cast"
)

var (
	CUSTOMER_ROLE = "customer"
	VENDOR_ROLE   = "vendor"
	ENGINEER_ROLE = "engineer"
	ADMIN_ROLE    = "admin"
)

type User struct {
	Id             int    `json:"id"`
	UserName       string `json:"user_name"`
	FirstName      string `json:"first_name"`
	LastName       string `json:"last_name"`
	EmailId        string `json:"email_id"`
	PhoneNumber    string `json:"phone_number"`
	Enable         int    `json:"enable"`
	Role           string `json:"role"`
	Picture        string `json:"picture"`
	Status         int    `json:"status"`
	OrganisationId []int  `json:"organisationId"`
}

type UserDetails struct {
	User        *User
	Permission  []orm.Params
	ExpiredTime time.Time
}

func GetSessionUserDetails(w http.ResponseWriter, r *http.Request) (UserDetails, error) {
	authId := r.Header.Get("Authorization")
	if strings.Contains(authId, "Bearer ") {
		auth := strings.Split(authId, "Bearer ")
		fmt.Println("Authorization token :", auth)
		authId = cast.ToString(auth[1])
	}
	return AuthTokenDecoder(authId)
}

func CheckCurrentUserAccessPermission(currentUser UserDetails, requestapi string) bool {
	flag := false
	UserRole := currentUser.Permission
	for _, value := range UserRole {
		fmt.Println("role:", value["action"], value["enable"])
		if value["action"] == requestapi && cast.ToInt(value["enable"]) == 1 {
			flag = true
		}
	}

	return flag
}

func CheckCurrentUserIsCompanyAccessPermission(currentUser UserDetails, companyId int, requestapi string) bool {
	flag := false
	UserRole := currentUser.Permission
	for _, value := range UserRole {
		if cast.ToInt(value["company_id"]) == companyId &&
			value["action"] == requestapi &&
			cast.ToInt(value["enable"]) == 1 {
			flag = true
		} else if cast.ToInt(value["company_id"]) == 0 &&
			value["action"] == requestapi &&
			cast.ToInt(value["enable"]) == 1 {
			flag = true
		}
	}

	return flag
}

func MaskString(any string, length int) string {
	if len(any) <= length {
		return any
	}
	return strings.Repeat("x", len(any)-length) + any[len(any)-length:]
}


func AuthTokenEncoder(details UserDetails) string {
	userDetailsJson, _ := json.Marshal(details)
	fmt.Println(string(userDetailsJson))
	if config.ENV=="prod"{
       return SHA_HASH_KEY + "." + b64.StdEncoding.EncodeToString([]byte(userDetailsJson))
	}
	return b64.StdEncoding.EncodeToString([]byte(userDetailsJson))
}

func AuthTokenDecoder(str string) (UserDetails, error) {
	userDetailsJson := UserDetails{}
	if config.ENV == "prod"{
	    str = strings.Replace(str, SHA_HASH_KEY +"." , "" ,1)
	}
	sDec, _ := b64.StdEncoding.DecodeString(str)
	if err := json.Unmarshal(sDec, &userDetailsJson); err == nil && userDetailsJson.User != nil {
		fmt.Println(userDetailsJson.User)
		return userDetailsJson, nil
	}
	return userDetailsJson, errors.New("User Not Found")
}

func IsUserAuthTokenNotValid(details UserDetails) bool {
	if details.User == nil {
		return true
	}
	now := time.Now()
	if details.ExpiredTime.Format("20060102150405") >= now.Format("20060102150405") {
		logs.Info("IsUserAuthTokenNotValid: ", now.String(), details.ExpiredTime.String())
		return false
	}
	return true
}
