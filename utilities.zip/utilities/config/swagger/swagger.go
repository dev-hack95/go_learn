package swagger

import (
	"net/http"
	"os"

	"github.com/spf13/cast"
	"github.com/spf13/viper"
)

var (
	IS_ENABLE_SWAGGER = false
)

//function to register the database to beego orm
func SetupSwagger(ENV string) {

	if viper.Get(ENV+".swagger") != nil {
		swagger := viper.Get(ENV + ".swagger").(map[string]interface{})
		IS_ENABLE_SWAGGER = cast.ToBool(swagger["enable"])
	}
}

func SwaggerHandler(w http.ResponseWriter, r *http.Request) {
	data, _ := os.ReadFile("./conf/swagger/swagger.yaml")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Write(data)
}
