package persistent

import (
	"time"

	"com.awesomesuite.project/utilities/logs"
	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql"
	"github.com/spf13/viper"
)

var (
	DEFAULT_TIME = time.UTC
	maxIdle      = 5
	maxConn      = 30
)

//function to register the database to beego orm
func RegisterDatabase(runmode, timeZone string) {
	logs.Info("Env", runmode)
	if viper.Get(runmode+".mysql") != nil {
		mysql := viper.Get(runmode + ".mysql").(map[string]interface{})
		mysqlConf := mysql["user"].(string) + ":" + mysql["password"].(string) + "@tcp(" + mysql["host"].(string) + ")/" + mysql["database"].(string) + "?charset=utf8"
		logs.Info("conf", mysqlConf)
		if err := orm.RegisterDataBase("default", "mysql", mysqlConf, maxIdle, maxConn); err != nil {
			logs.Error("error : ", err.Error())
		}
		orm.DefaultTimeLoc = DEFAULT_TIME
		if timeZone != "" {
			orm.DefaultTimeLoc, _ = time.LoadLocation(timeZone)
		}
		orm.Debug = true
	}
}
