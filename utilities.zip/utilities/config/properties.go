package config

import (
	"os"

	"com.awesomesuite.project/utilities/logs"
	"github.com/spf13/cast"
	"github.com/spf13/viper"
)

var (
	ENV         string
	ContextPATH string
)

//set up config file from conf folder
func SetConfigurationProperties() {
	viper.AddConfigPath("./conf")
	viper.SetConfigName("env")

	if err := viper.ReadInConfig(); err != nil {
		logs.Error("Error reading config file, %s", err)
	}
	viper.SetEnvPrefix("global")
	runmode := os.Getenv("RUNMODE")
	if runmode != "" {
		ENV = runmode
	} else {
		ENV = cast.ToString(viper.Get("runmode"))
	}

	if ENV == "prod" {
		viper.AddConfigPath("./conf")
		viper.SetConfigName("prod")
		if err := viper.MergeInConfig(); err != nil {
			logs.Error("Error reading prod config file, %s", err)
		}
	}

}

func SetServiceContextPath() {
	if viper.Get(ENV+".context-path") != nil {
		ContextPATH = viper.Get(ENV + ".context-path").(string)
	} else {
		ContextPATH = ""
	}
}
