package errorMessage

import (
	"com.awesomesuite.project/utilities/logs"
	"github.com/spf13/viper"
)

var (
	errorMapping map[string]interface{}
)

func SetErrorMessageProperties() {
	if viper.Get("error") != nil {
		logs.Info("Error Initialization ...")
		errorMapping = viper.Get("error").(map[string]interface{})
	}
}

func GetErrMsg(errorKey string) string {
	if errorMapping == nil {
		return ""
	}

	if errorMapping[errorKey] == nil {
		return ""
	}

	return errorMapping[errorKey].(string)
}
