package utilities

import (
	"net/http"
	"strings"

	"com.awesomesuite.project/utilities/config"
	"com.awesomesuite.project/utilities/logs"
	"github.com/davecgh/go-spew/spew"
)

var (
	GETALL = "GETALL"
	GETONE = "GETONE"
	POST   = "POST"
	PUT    = "PUT"
	PATCH  = "PATCH"
	EXPORT = "EXPORT"
	IMPORT = "IMPORT"
	DELETE = "DELETE"
	SNS    = "SNS"
)

func Mapping(r *http.Request, method string) bool {
	ID := r.URL.Query().Get("id")
	export := r.URL.Query().Get("export")
	Import := r.URL.Query().Get("import")
	sns := r.Header.Get("X-Amz-Sns-Message-Type")

	//Subscription Confirmation Check First Time
	if sns == "SubscriptionConfirmation" {
		logs.Info("SNS Notification", sns)
		spew.Dump(r)
		return false
	}

	switch true {
	case r.Method == "GET" && (ID == "" || ID == "0") && method == GETALL && (export == "" || export == "false"):
		return true

	case r.Method == "GET" && ID == "0" && method == EXPORT && export == "true":
		return true

	case r.Method == "GET" && ID != "" && method == GETONE:
		return true

	case r.Method == "POST" && method == SNS && sns == "Notification":
		return true

	case r.Method == "POST" && method == POST && (Import == "" || Import == "false") && sns != "Notification":
		return true

	case r.Method == "POST" && method == IMPORT && Import == "true" && sns != "Notification":
		return true

	case r.Method == "PUT" && method == PUT:
		return true

	case r.Method == "PATCH" && method == PATCH:
		return true

	case r.Method == "DELETE" && method == DELETE:
		return true
	}

	return false
}

func HandleFunc(mux *http.ServeMux, pattern string, handler func(http.ResponseWriter, *http.Request)) {
	if !IsEmpty(config.ContextPATH) {
		if strings.Contains(pattern, "/") {
			mux.HandleFunc("/"+config.ContextPATH+pattern, handler)
		} else {
			mux.HandleFunc("/"+config.ContextPATH+"/"+pattern, handler)
		}
	} else {
		mux.HandleFunc(pattern, handler)
	}
}
