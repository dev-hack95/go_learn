package utilities

import (
	"bytes"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net/http"
	"strings"
	"time"

	"com.awesomesuite.project/utilities/logs"
	"github.com/davecgh/go-spew/spew"
	"github.com/spf13/cast"
)

var letterRunes = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

type RedisRequest struct {
	Url  string `json:"url"`
	Body string `json:"body"`
}

func RandString(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

func HasScheduledTimePassed(scheduledTime time.Time, zone string) (bool, error) {
	// Refer to different timezone available: https://go.dev/src/time/zoneinfo_abbrs_windows.go
	location, err := time.LoadLocation(zone)
	if err != nil {
		return false, err
	}
	/*currentTime: 2023 4 16 16 39 7
	  scheduledTime: 2023 4 16 15 40 0*/
	currTime := time.Now().In(location)
	fmt.Println("time location:", location)
	fmt.Println("currentTime:", currTime.Year(), int(currTime.Month()), currTime.Day(), currTime.Hour(), currTime.Minute(), currTime.Second())
	fmt.Println("scheduledTime:", scheduledTime.Year(), int(scheduledTime.Month()), scheduledTime.Day(), scheduledTime.Hour(), scheduledTime.Minute(), scheduledTime.Second())
	if currTime.Year() > scheduledTime.Year() ||
		(currTime.Year() == scheduledTime.Year() && (int(currTime.Month()) > int(scheduledTime.Month()) ||
			(int(currTime.Month()) == int(scheduledTime.Month()) && (currTime.Day() > scheduledTime.Day() ||
				(currTime.Day() == scheduledTime.Day() && (currTime.Hour() > scheduledTime.Hour() ||
					(currTime.Hour() == scheduledTime.Hour() && (currTime.Minute() > scheduledTime.Minute() ||
						(currTime.Minute() == scheduledTime.Minute() && currTime.Second() >= scheduledTime.Second()))))))))) {
		fmt.Println("currentTime > scheduledTime", scheduledTime)
		return true, nil
	}
	return false, nil
}

func ConvertToUtc(scheduledTime time.Time) (utcDateTime time.Time, err error) {
	dateTimeStr := cast.ToString(scheduledTime)
	timeStrArr := make([]string, 0)

	if strings.Contains(dateTimeStr, ".") {
		timeStrArr = strings.Split(dateTimeStr, ".")
		temp := strings.Replace(timeStrArr[0], " ", "T", 1) + ".00Z"
		utcDateTime, err = time.Parse(time.RFC3339, temp)

		if err != nil {
			logs.Error("Error:", err.Error())
			err = errors.New("Error: while get converting to UTC format " + err.Error())
			return scheduledTime, err
		}
	}
	return utcDateTime, nil
}

func PostHttpClient(urlStr string, requestBody interface{}) interface{} {
	fmt.Println("Url: ", urlStr)
	spew.Dump(requestBody)
	requestJSON, err := json.Marshal(requestBody)
	var outputObj interface{}
	req, err := http.NewRequest("POST", urlStr, bytes.NewBuffer(requestJSON))
	if err != nil {
		return nil
	}
	req.Header.Set("Content-Te", "application/json")
	// req.Header.Add("Authorization", cast.ToString(viper.Get("usertoken")))
	client := &http.Client{}
	//send the request
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	json.Unmarshal(body, &outputObj)
	fmt.Println("Response: ", outputObj)
	return outputObj
}

func GetHttpClient(urlStr string) interface{} /*map[interface{}]interface{}*/ {
	var outputObj interface{} //make(map[interface{}]interface{})
	req, err := http.NewRequest("GET", urlStr, nil)
	if err != nil {
		return nil
	}
	req.Header.Set("Content-Te", "application/json")
	// req.Header.Add("Authorization", cast.ToString(viper.Get("usertoken")))
	client := &http.Client{}
	//send the request
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	json.Unmarshal(body, &outputObj)
	fmt.Println(resp.Body)

	return outputObj
}

// GenerateCSV
func GenerateCSV(csvContent [][]string) []byte {
	b := &bytes.Buffer{}   // creates IO Writer
	wr := csv.NewWriter(b) // creates a csv writer that uses the io buffer.
	for i := 0; i < len(csvContent); i++ {
		wr.Write(csvContent[i]) // converts array of string to comma seperated values for 1 row.
	}
	wr.Flush() // writes the csv writer data to  the buffered data io writer(b(bytes.buffer))

	b.Bytes()

	return b.Bytes()
}

func ImportCsvFunction(req *http.Request) (row [][]string, err error) {
	s := ""
	if req.Method == http.MethodPost {
		f, _, err := req.FormFile("file")
		if err != nil {
			fmt.Println(err)
			return nil, err
		}

		defer f.Close()
		// log.Printf(h)
		bs, err := ioutil.ReadAll(f)
		if err != nil {
			fmt.Println(err)
			return nil, err
		}
		s = string(bs)
	}

	NumberOfRow := strings.Split(s, "\n")
	for _, value := range NumberOfRow {
		rowRecord := strings.Split(value, ",")
		if len(rowRecord) > 0 {
			row = append(row, rowRecord)
		}

	}

	return row, nil
}

func MaskLeft(s string) string {
	rs := []rune(s)
	for i := 0; i < len(rs)-4; i++ {
		rs[i] = 'X'
	}
	return string(rs)
}

func IsEmpty(s interface{}) bool {
	if s == nil || cast.ToString(s) == "" {
		return true
	}
	return false
}

func Toggle(flag int) int {
	if flag == 0 {
		return 1
	}
	return 0
}

func Mapper(model interface{}, entity interface{}) error {
	data, err := json.Marshal(model) // Convert to a json string
	if err != nil {
		return err
	}
	err = json.Unmarshal(data, &entity)
	if err != nil {
		return err
	}
	return nil
}

func ConvertToUnix(Time time.Time) (unixTime int64) {
	utcDateTime := Time.UTC()
	unixTime = utcDateTime.Unix()
	return unixTime
}
