package services

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
)

var (
	USER_URL string
)

type USER_RESPONSE struct {
	Code  int           `json:"code"`
	Msg   string        `json:"msg"`
	Model []UserDetails `json:"model"`
}

type UserDetails struct {
	EmailID     string `json:"email_id"`
	FirstName   string `json:"first_name"`
	ID          string `json:"id"`
	LastName    string `json:"last_name"`
	PhoneNumber string `json:"phone_number"`
	Picture     string `json:"picture"`
	UserName    string `json:"user_name"`
	Status      string `json:"status"`
}

func GetUsersByUserIds(ids string) (users []UserDetails) {
	url := USER_URL + "&id=" + ids
	fmt.Println(url)
	resp, err := http.Get(url)
	if err != nil {
		fmt.Println("USERINFO API Call Failed: {}", err.Error())
		return nil
	}
	var response USER_RESPONSE
	body, _ := ioutil.ReadAll(resp.Body)
	json.Unmarshal(body, &response)
	if response.Code != 200 {
		return nil
	}
	if response.Model == nil {
		return nil
	}

	fmt.Println(response.Model)
	users = response.Model
	return
}

func GetUsersByEmailIds(ids []string) (users []UserDetails) {
	url := USER_URL + "&action=userinfo"
	data, err := json.Marshal(ids)
	if err != nil {
		return nil
	}
	fmt.Println(url, string(data))
	resp, err := http.Post(url, "", bytes.NewReader(data))
	if err != nil {
		fmt.Println("USERINFO API Call Failed: {}", err.Error())
		return nil
	}
	var response USER_RESPONSE
	body, _ := ioutil.ReadAll(resp.Body)
	json.Unmarshal(body, &response)
	if response.Code != 200 {
		return nil
	}
	if response.Model == nil {
		return nil
	}

	fmt.Println(response.Model)
	users = response.Model
	return
}
