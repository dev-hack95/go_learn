package utilities

import (
	"time"

	"github.com/spf13/cast"
)

var (
	NOTIFICATION_TOPIC_NAME  string
	NOTIFICATION_PRODUCT_ID  int
	NOTIFICATION_NOTIFIER_ID int
)

type Notification struct {
	EntityType int    `json:"entity_type"`
	EntityID   int    `json:"entity_id"`
	CreatedOn  string `json:"_created_on"`
	UserID     int    `json:"user_id"`
}

type NotificationStruct struct {
	Notification        Notification      `json:"notification"`
	DynamicTemplateData map[string]string `json:"dynamicTemplateData"`
	RelatedID           int               `json:"related_id"`
	ProductID           int               `json:"product_id"`
	NotifierID          int               `json:"notifier_id"`
	TemplateID          string            `json:"template_id"`
	SendEmail           bool              `json:"send_email"`
	EventType           string            `json:"event_type"`
	OrganizationID      int               `json:"org_id"`
}

func SendNotification(
	param map[string]string,
	userId, entity_id int, entity_type int, sendEmail bool, event_type string, orgId int) (ok bool) {

	notifcation := Notification{
		EntityType: entity_type,
		EntityID:   entity_id,
		UserID:     userId,
		CreatedOn:  time.Now().Local().String(),
	}
	var related_id int
	switch event_type {
	case "brand":
		related_id = cast.ToInt(param["brandID"])
		break
	case "workflow":
		related_id = userId
		break
	default:
		related_id = cast.ToInt(param["workspace_id"])
	}

	noficationObject := NotificationStruct{
		Notification:        notifcation,
		DynamicTemplateData: param,
		RelatedID:           related_id,
		ProductID:           NOTIFICATION_PRODUCT_ID,
		NotifierID:          NOTIFICATION_NOTIFIER_ID,
		TemplateID:          param["template_id"],
		SendEmail:           sendEmail,
		EventType:           event_type,
		OrganizationID:      orgId,
	}

	if err := PublishSnsV2(noficationObject, NOTIFICATION_TOPIC_NAME); err == nil {
		return true
	}
	return false
}
