package utilities

import (
	"com.awesomesuite.project/utilities/logs"
	"encoding/json"
	"fmt"
	"strings"

	"com.awesomesuite.project/utilities/config"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sns"
	_ "github.com/lib/pq"
	"github.com/spf13/cast"
	"github.com/spf13/viper"
)

const (
	EVENT_SRC_QUEUE = "EVENT_SRC_QUEUE"
)

type snsMessagePayload struct {
	Message      interface{} `json:"message"`
	SourceSystem string      `json:"sourceSystem"`
	FlowName     string      `json:"flowName"`
}

func PublishSnsV2(data interface{}, topic string) error {
	srcSystem := viper.GetString(config.ENV + ".context-path")
	topicArn := viper.GetString(config.ENV + ".sns.topics." + topic)
	region := viper.GetString(config.ENV + ".sns.region")
	arr := strings.Split(topicArn, ":")
	queueName := arr[(len(arr) - 1)]
	topicArn = strings.ReplaceAll(topicArn, queueName, EVENT_SRC_QUEUE)

	fmt.Println("FlowName : ", queueName)
	fmt.Println("Topic Arn : ", topicArn)
	message := snsMessagePayload{Message: data, FlowName: queueName, SourceSystem: srcSystem}
	snsMessage, err := json.Marshal(message)
	if err != nil {
		return err
	}
	fmt.Println("SNS MESSAGE to be sent ", string(snsMessage))

	sess, err := session.NewSession(&aws.Config{
		Region: aws.String(region),
	})

	if err != nil {
		logs.Error("Error:", "Failure: Error creating SNS session!", err.Error())
		return err
	}

	svc := sns.New(sess)
	params := &sns.PublishInput{
		Message:  aws.String(string(snsMessage)), // This is the message itself (can be XML / JSON / Text - anything you want)
		TopicArn: aws.String(topicArn),           //Get this from the Topic in the AWS console.
	}

	resp, err := svc.Publish(params) //Call to publish the message
	if err != nil {
		logs.Error("Error:", "Call to publish message", err.Error())
		return err
	}
	logs.Info("Repsonse SNS:", string(resp.GoString()))
	return nil
}

func PublishSns(message interface{}, topic string) (returnJson ResponseJSON) {
	snsMessage, err := json.Marshal(message)
	if err != nil {
		ErrorResponse(&returnJson, "Failed!")
		return
	}

	fmt.Println("SNS MESSAGE to be sent ", string(snsMessage))
	topicArn := viper.GetString(config.ENV + ".sns.topics." + topic)
	region := viper.GetString(config.ENV + ".sns.region")
	fmt.Println("Topic Arn : ", topicArn)

	sess, err := session.NewSession(&aws.Config{
		Region: aws.String(region),
	})

	if err != nil {
		ErrorResponse(&returnJson, "Failure: Error creating SNS session!")
		return
	}

	svc := sns.New(sess)
	params := &sns.PublishInput{
		Message:  aws.String(string(snsMessage)), // This is the message itself (can be XML / JSON / Text - anything you want)
		TopicArn: aws.String(topicArn),           //Get this from the Topic in the AWS console.
	}

	resp, err := svc.Publish(params) //Call to publish the message
	if err != nil {
		ErrorResponse(&returnJson, "Failure: Error Call to publish message"+cast.ToString(err))
		return
	}
	SuccessResponse(&returnJson, resp)
	return

}
