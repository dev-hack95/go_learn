package utilities

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"net/http"

	"github.com/davecgh/go-spew/spew"
)

type ResponseJSON struct {
	Code  int         `json:"code"`
	Msg   string      `json:"msg"`
	Model interface{} `json:"model"`
}

type AllGridJson struct {
	Page    int         `json:"page"`
	Total   float64     `json:"total"`
	Records int64       `json:"records"`
	Rows    interface{} `json:"rows"`
}

func UnprocessableResponse(returnData *ResponseJSON) {
	returnData.Code = 422
	returnData.Msg = "Failure: Unprocessable data error"
	returnData.Model = nil
}

func UnAuthorizationResponse(returnData *ResponseJSON) {
	fmt.Println("Not Authorized to access this resource")
	returnData.Code = 404
	returnData.Msg = "Failure:Authorization error"
	returnData.Model = nil
}

func InvalidSessionResponse(returnData *ResponseJSON) {
	returnData.Msg = "Error: Invalid Session!"
	returnData.Code = 406
}

func ErrorResponse(returnData *ResponseJSON, msg string) {
	returnData.Msg = msg
	returnData.Code = 400
}

func SuccessResponse(returnData *ResponseJSON, data interface{}) {
	returnData.Msg = "success"
	returnData.Code = 200
	returnData.Model = data
}

func URLReturnResponseJson(w http.ResponseWriter, data interface{}) {
	w.Header().Del("currentUser")
	returnJson, _ := json.Marshal(data)
	w.Header().Set("Access-Control-Allow-Origin", "*")
	// w.Header().Set("Cache-Control", "max-age=300")
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(returnJson)
}

func URLReturnResponseCSV(w http.ResponseWriter, data interface{}) {
	w.Header().Del("currentUser")
}

func URLReturnResponseXML(w http.ResponseWriter, data interface{}) {
	spew.Dump("================ API RESPONSE ================", data, "======== END RESPONSE ========")
	returnXML, _ := xml.Marshal(data)
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Content-Type", "application/xml")
	w.WriteHeader(http.StatusOK)
	w.Write(returnXML)
}
