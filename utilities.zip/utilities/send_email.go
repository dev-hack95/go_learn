package utilities

var EMAIL_TOPIC_NAME string

type Email struct {
	FromEmail           string            `json:"fromEmail"`
	ToEmail             string            `json:"toEmail"`
	TemplateID          string            `json:"templateId"`
	DynamicTemplateData map[string]string `json:"dynamicTemplateData"`
	Sender              string            `json:"sender"`
	IsParam             bool              `json:"isParam"`
	IsTemplate          bool              `json:"isTemplate"`
}

func SendEmailwithTemplateID(dynamicTemplate map[string]string, templateID string, toEmail string, fromEmail string) (ok bool) {
	email := Email{
		FromEmail:           fromEmail,
		ToEmail:             toEmail,
		TemplateID:          templateID,
		DynamicTemplateData: dynamicTemplate,
		Sender:              "sendgrid",
		IsParam:             true,
		IsTemplate:          true,
	}

	if err := PublishSnsV2(email, EMAIL_TOPIC_NAME); err == nil {
		return true
	}
	return false
}
